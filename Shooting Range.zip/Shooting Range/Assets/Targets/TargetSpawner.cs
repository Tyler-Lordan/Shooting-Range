using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TargetSpawner : MonoBehaviour
{
    float timer = 5;
    float currTime;
    public GameObject target;
    Vector3 rotate = new Vector3(90,0,0);

    // Start is called before the first frame update
    void Start()
    {
        currTime = timer;
    }

    // Update is called once per frame
    void Update()
    {
        if(currTime <= 0) {
            Instantiate(target, transform.position + (transform.forward*2), transform.rotation);
            currTime = timer;
        }
        else
        {
            currTime -= Time.deltaTime;
        }
    }
}
