using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TargetScript : MonoBehaviour
{
    float time;
    public float speed = 20;
    public float lifeSpan = 20;
    Vector3 gravity = new Vector3(0, -0.5f, 0);
    private void Start()
    {
        time = 0;
        gameObject.GetComponent<Rigidbody>().AddForce(gravity);
    }

    // Update is called once per frame
    void Update()
    {
        transform.position += transform.forward * speed * Time.deltaTime;
        time += Time.deltaTime;

        if (time >= lifeSpan)
        {
            breakTarget();
        }
    }

    public void breakTarget()
    {
        Destroy(gameObject);
    }
}
