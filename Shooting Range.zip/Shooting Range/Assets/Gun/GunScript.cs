using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class GunScript : MonoBehaviour
{
    bool isAnimating;
    float mouseX;
    float mouseY;
    public float sens;
    public GameObject bullet;
    Vector3 bulletDiff = new Vector3(90,0,0);
    public float fireRate = 1;
    float currTime;
    public GameObject gun;
    public GameObject score;

    // Start is called before the first frame update
    void Start()
    {
        mouseX = 0;
        mouseY = 0;
        isAnimating = false;
        currTime = fireRate;
    }

    // Update is called once per frame
    void Update()
    {
        if(isAnimating)
        {
            if (currTime <= 0)
            {
                gun.transform.localRotation = Quaternion.Euler(0, 180, 0);
                isAnimating = false;
            }
            else currTime -= Time.deltaTime;
        }

        mouseX += Input.GetAxis("Mouse X");
        mouseY += Input.GetAxis("Mouse Y");
        transform.localRotation = Quaternion.Euler(-mouseY, mouseX, 0);
        if(Input.GetMouseButtonDown(0) && !isAnimating)
        {
            Instantiate(bullet, transform.position+(transform.forward*2), transform.rotation);
            isAnimating = true;
            gun.transform.localRotation = Quaternion.Euler(20, 180, 0);
            currTime = fireRate;
        }
    }
}
