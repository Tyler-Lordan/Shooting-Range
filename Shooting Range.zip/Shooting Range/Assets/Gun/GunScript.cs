using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class GunScript : MonoBehaviour
{
    bool isAnimating;
    float mouseX;
    float mouseY;
    public float sens;
    public GameObject bullet;
    Vector3 bulletDiff = new Vector3(90,0,0);
    public float fireRate = 1;
    float currTime;
    public GameObject gun;
    public GameObject score;

    // Start is called before the first frame update
    void Start()
    {
        mouseX = 0;
        mouseY = 0;
        isAnimating = false;
        currTime = fireRate;
    }

    // Update is called once per frame
    void Update()
    {
        if(isAnimating)
        {
            if (currTime <= 0)
            {
                gun.transform.localRotation = Quaternion.Euler(0, 180, 0);
                isAnimating = false;
            }
            else currTime -= Time.deltaTime;
        }

        mouseX += Input.GetAxis("Mouse X");
        mouseY += Input.GetAxis("Mouse Y");
        transform.localRotation = Quaternion.Euler(-mouseY, mouseX, 0);
        if(Input.GetMouseButtonDown(0) && !isAnimating)
        {
            Vector3 origin = transform.position + (transform.forward * 2);
            Instantiate(bullet, origin, transform.rotation);
            Ray ray = new Ray(origin, transform.forward);
            Debug.DrawRay(origin, transform.forward, Color.red, 5f, false);
            if(Physics.Raycast(ray, out RaycastHit hit, float.MaxValue, LayerMask.GetMask("Target")))
            {
                Debug.Log("Hit");
                if(hit.collider.gameObject.TryGetComponent<TargetScript>(out TargetScript target))
                {
                    target.breakTarget();
                    Debug.Log("Reached here." + target.gameObject.name);
                }
            }
            isAnimating = true;
            gun.transform.localRotation = Quaternion.Euler(20, 180, 0);
            currTime = fireRate;
        }
    }
}
