using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BulletScript : MonoBehaviour
{
    float time;
    public float speed = 20;
    public float lifeSpan = 20;
    private void Start()
    {
        time = 0;
    }

    // Update is called once per frame
    void Update()
    {
        transform.position += transform.forward * speed * Time.deltaTime;
        time += Time.deltaTime;
        if(time >= lifeSpan)
        {
            Destroy(gameObject);
        }
    }
}
